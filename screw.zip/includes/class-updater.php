<?php
/**
 * 自動更新クラス
 *
 * @package Screw
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SC_Updater {

    /**
     * シングルトンインスタンス
     *
     * @var SC_Updater
     */
    private static $instance = null;

    /**
     * GitHub リポジトリのオーナー
     */
    private $github_owner = 'villyoshioka';

    /**
     * GitHub リポジトリ名
     */
    private $github_repo = 'Screw';

    /**
     * プラグインのベースネーム
     */
    private $plugin_basename;

    /**
     * プラグインのスラッグ
     */
    private $plugin_slug;

    /**
     * 現在のバージョン
     */
    private $current_version;

    /**
     * キャッシュキー
     */
    private $cache_key = 'sc_github_release_cache';

    /**
     * キャッシュ有効期間（秒）
     */
    private $cache_expiry = 43200; // 12時間

    /**
     * シングルトンインスタンスを取得
     *
     * @return SC_Updater
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * コンストラクタ
     */
    private function __construct() {
        $this->plugin_basename = SC_PLUGIN_BASENAME;
        $this->plugin_slug = dirname( $this->plugin_basename );
        $this->current_version = SC_VERSION;

        // フックを登録
        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
        add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );
        add_filter( 'upgrader_source_selection', array( $this, 'fix_source_dir' ), 10, 4 );
        add_action( 'upgrader_process_complete', array( $this, 'on_upgrade_complete' ), 10, 2 );
    }

    /**
     * プラグイン更新完了時にキャッシュをクリア
     *
     * @param WP_Upgrader $upgrader アップグレーダーインスタンス
     * @param array       $options  更新オプション
     */
    public function on_upgrade_complete( $upgrader, $options ) {
        // プラグイン更新の場合のみ処理
        if ( $options['action'] !== 'update' || $options['type'] !== 'plugin' ) {
            return;
        }

        // このプラグインが更新対象に含まれているかチェック
        $plugins = isset( $options['plugins'] ) ? $options['plugins'] : array();
        if ( ! is_array( $plugins ) ) {
            $plugins = array( $plugins );
        }

        if ( in_array( $this->plugin_basename, $plugins, true ) ) {
            // GitHubリリースキャッシュをクリア（通常キャッシュとベータ用キャッシュ両方）
            delete_transient( $this->cache_key );
            delete_transient( $this->cache_key . '_beta' );

            // WordPressの更新トランジェントからこのプラグインを削除
            $update_plugins = get_site_transient( 'update_plugins' );
            if ( $update_plugins && isset( $update_plugins->response[ $this->plugin_basename ] ) ) {
                unset( $update_plugins->response[ $this->plugin_basename ] );
                set_site_transient( 'update_plugins', $update_plugins );
            }
        }
    }

    /**
     * 更新をチェック
     *
     * @param object $transient 更新トランジェント
     * @return object 更新されたトランジェント
     */
    public function check_for_update( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        // WordPressが認識している実際のインストール済みバージョンを使用
        $current_version = isset( $transient->checked[ $this->plugin_basename ] )
            ? $transient->checked[ $this->plugin_basename ]
            : $this->current_version;

        $release = $this->get_latest_release();

        if ( ! $release ) {
            return $transient;
        }

        $latest_version = ltrim( $release['tag_name'], 'v' );

        // メジャーバージョンチェック（メジャーバージョンが異なる場合は自動更新を提供しない）
        $current_parts = explode( '.', $current_version );
        $latest_parts = explode( '.', $latest_version );
        $current_major = isset( $current_parts[0] ) ? (int) $current_parts[0] : 0;
        $latest_major = isset( $latest_parts[0] ) ? (int) $latest_parts[0] : 0;

        if ( $current_major !== $latest_major ) {
            // メジャーバージョンが異なる場合は自動更新を提供しない
            return $transient;
        }

        if ( version_compare( $current_version, $latest_version, '<' ) ) {
            $download_url = $this->get_download_url( $release );

            if ( $download_url ) {
                $transient->response[ $this->plugin_basename ] = (object) array(
                    'slug'        => $this->plugin_slug,
                    'plugin'      => $this->plugin_basename,
                    'new_version' => $latest_version,
                    'url'         => $release['html_url'],
                    'package'     => $download_url,
                    'icons'       => array(),
                    'banners'     => array(),
                    'tested'      => '',
                    'requires_php' => '7.4',
                );
            }
        } else {
            // 更新不要の場合、responseから削除してno_updateに移動
            if ( isset( $transient->response[ $this->plugin_basename ] ) ) {
                unset( $transient->response[ $this->plugin_basename ] );
            }
            // no_updateに登録（最新版であることを明示）
            if ( ! isset( $transient->no_update[ $this->plugin_basename ] ) ) {
                $transient->no_update[ $this->plugin_basename ] = (object) array(
                    'slug'        => $this->plugin_slug,
                    'plugin'      => $this->plugin_basename,
                    'new_version' => $current_version,
                    'url'         => '',
                    'package'     => '',
                );
            }
        }

        return $transient;
    }

    /**
     * プラグイン情報を取得（詳細ポップアップ用）
     *
     * @param false|object|array $result 結果
     * @param string $action アクション
     * @param object $args 引数
     * @return false|object 結果
     */
    public function plugin_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' ) {
            return $result;
        }

        if ( 'screw' !== $args->slug ) {
            return $result;
        }

        $release = $this->get_latest_release();

        if ( ! $release ) {
            return $result;
        }

        $latest_version = ltrim( $release['tag_name'], 'v' );
        $download_url = $this->get_download_url( $release );

        return (object) array(
            'name'              => 'Screw',
            'slug'              => $this->plugin_slug,
            'version'           => $latest_version,
            'author'            => '<a href="https://github.com/villyoshioka">villyoshioka</a>',
            'author_profile'    => 'https://github.com/villyoshioka',
            'homepage'          => 'https://github.com/villyoshioka/Screw',
            'short_description' => 'WordPressサイトにオリジナル画像でのローディング画面を表示するプラグイン',
            'sections'          => array(
                'description'  => $this->get_readme_description(),
                'changelog'    => $this->format_changelog( $release['body'] ),
            ),
            'download_link'     => $download_url,
            'requires'          => '6.0',
            'tested'            => '',
            'requires_php'      => '7.4',
            'last_updated'      => $release['published_at'],
        );
    }

    /**
     * GitHub から最新リリース情報を取得
     *
     * @return array|false リリース情報または失敗時false
     */
    private function get_latest_release() {
        // ベータチャンネルが有効かどうかを確認
        $include_prerelease = $this->is_beta_channel_enabled();

        // キャッシュキーを分ける（ベータとノーマル）
        $cache_key = $include_prerelease ? $this->cache_key . '_beta' : $this->cache_key;

        // キャッシュをチェック
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        // ベータチャンネルの場合は全リリースを取得、通常は最新のみ
        if ( $include_prerelease ) {
            $url = sprintf(
                'https://api.github.com/repos/%s/%s/releases',
                $this->github_owner,
                $this->github_repo
            );
        } else {
            $url = sprintf(
                'https://api.github.com/repos/%s/%s/releases/latest',
                $this->github_owner,
                $this->github_repo
            );
        }

        $response = wp_safe_remote_get( $url, array(
            'timeout' => 10,
            'headers' => array(
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url(),
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        if ( $status_code !== 200 ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        // JSONデコードエラーチェック
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return false;
        }

        // ベータチャンネルの場合は配列から最新を選択
        if ( $include_prerelease ) {
            $body = $this->get_latest_from_releases( $body );
        }

        // 必須フィールドの検証
        if ( empty( $body ) || ! is_array( $body ) ) {
            return false;
        }

        $required_fields = array( 'tag_name', 'html_url', 'zipball_url' );
        foreach ( $required_fields as $field ) {
            if ( ! isset( $body[ $field ] ) || ! is_string( $body[ $field ] ) ) {
                return false;
            }
        }

        // tag_name の形式を検証（vX.X.X または X.X.X）
        if ( ! preg_match( '/^v?\d+\.\d+(\.\d+)?(-[a-zA-Z0-9.]+)?$/', $body['tag_name'] ) ) {
            return false;
        }

        // キャッシュに保存
        set_transient( $cache_key, $body, $this->cache_expiry );

        return $body;
    }

    /**
     * ベータチャンネルが有効かどうかを確認
     *
     * @return bool 有効ならtrue
     */
    private function is_beta_channel_enabled() {
        return (bool) get_transient( 'sc_beta_channel' );
    }

    /**
     * リリース一覧から最新のリリースを取得（プレリリース含む）
     *
     * @param array $releases リリース一覧
     * @return array|false 最新のリリース情報
     */
    private function get_latest_from_releases( $releases ) {
        if ( empty( $releases ) || ! is_array( $releases ) ) {
            return false;
        }

        // リリースは公開日順（降順）で返されるので、最初の要素が最新
        // プレリリースも含めて最初のものを返す
        foreach ( $releases as $release ) {
            if ( is_array( $release ) && isset( $release['tag_name'] ) ) {
                return $release;
            }
        }

        return false;
    }

    /**
     * ダウンロードURLを取得
     *
     * @param array $release リリース情報
     * @return string|false ダウンロードURL
     */
    private function get_download_url( $release ) {
        // screw.zip という名前のアセットを探す
        if ( ! empty( $release['assets'] ) && is_array( $release['assets'] ) ) {
            foreach ( $release['assets'] as $asset ) {
                if ( isset( $asset['name'] ) && $asset['name'] === 'screw.zip' ) {
                    if ( isset( $asset['browser_download_url'] ) ) {
                        // SSRF対策: URLがGitHubのドメインであることを検証
                        if ( $this->is_valid_github_url( $asset['browser_download_url'] ) ) {
                            return $asset['browser_download_url'];
                        }
                    }
                }
            }
        }

        // screw.zip が見つからない場合はfalse
        return false;
    }

    /**
     * URLが正当なGitHub URLかどうかを検証
     *
     * @param string $url 検証するURL
     * @return bool 正当なGitHub URLならtrue
     */
    private function is_valid_github_url( $url ) {
        if ( empty( $url ) || ! is_string( $url ) ) {
            return false;
        }

        $parsed = wp_parse_url( $url );

        // スキームがhttpsであることを確認
        if ( ! isset( $parsed['scheme'] ) || $parsed['scheme'] !== 'https' ) {
            return false;
        }

        // ホストがGitHubのドメインであることを確認
        if ( ! isset( $parsed['host'] ) ) {
            return false;
        }

        $allowed_hosts = array(
            'api.github.com',
            'github.com',
            'codeload.github.com',
            'objects.githubusercontent.com', // リリースアセットのダウンロード先
        );

        if ( ! in_array( $parsed['host'], $allowed_hosts, true ) ) {
            return false;
        }

        // パスに期待するリポジトリ情報が含まれているか確認
        if ( ! isset( $parsed['path'] ) ) {
            return false;
        }

        // objects.githubusercontent.com はリダイレクト先なのでパス検証をスキップ
        if ( $parsed['host'] === 'objects.githubusercontent.com' ) {
            return true;
        }

        // リポジトリのowner/repoがパスに含まれていることを確認
        $expected_path_part = '/' . $this->github_owner . '/' . $this->github_repo;
        if ( strpos( $parsed['path'], $expected_path_part ) === false ) {
            return false;
        }

        return true;
    }

    /**
     * ソースディレクトリ名を修正
     *
     * GitHub の zipball は「owner-repo-hash」形式のディレクトリ名になるため、
     * 正しいプラグインディレクトリ名に修正する
     *
     * @param string $source ソースパス
     * @param string $remote_source リモートソース
     * @param WP_Upgrader $upgrader アップグレーダー
     * @param array $hook_extra 追加情報
     * @return string|WP_Error 修正されたソースパス
     */
    public function fix_source_dir( $source, $remote_source, $upgrader, $hook_extra ) {
        global $wp_filesystem;

        // このプラグインの更新かどうかを確認
        if ( ! isset( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->plugin_basename ) {
            return $source;
        }

        // 既に正しいディレクトリ名の場合はそのまま返す（リリースアセットからのインストール）
        $source_dirname = basename( untrailingslashit( $source ) );
        if ( $source_dirname === $this->plugin_slug ) {
            return $source;
        }

        // GitHubのzipball形式（owner-repo-hash）かどうかを確認
        $github_pattern = '/^' . preg_quote( $this->github_owner, '/' ) . '-' . preg_quote( $this->github_repo, '/' ) . '-[a-f0-9]+$/i';
        if ( ! preg_match( $github_pattern, $source_dirname ) ) {
            // 予期しない形式の場合はそのまま返す
            return $source;
        }

        // パストラバーサル対策: ソースパスの検証
        $real_source = realpath( $source );
        $real_remote = realpath( $remote_source );

        if ( $real_source === false || $real_remote === false ) {
            return new WP_Error( 'invalid_path', '無効なパスが検出されました。' );
        }

        // ソースがリモートソース内にあることを確認
        if ( strpos( $real_source, $real_remote ) !== 0 ) {
            return new WP_Error( 'path_traversal', 'パストラバーサルが検出されました。' );
        }

        // 正しいディレクトリ名
        $correct_dir = trailingslashit( $remote_source ) . $this->plugin_slug;

        // Null バイトチェック
        if ( strpos( $correct_dir, "\0" ) !== false ) {
            return new WP_Error( 'null_byte', '無効な文字が含まれています。' );
        }

        // 既に正しい名前のディレクトリが存在する場合は削除
        if ( $wp_filesystem->exists( $correct_dir ) ) {
            $wp_filesystem->delete( $correct_dir, true );
        }

        // ディレクトリ名を変更
        if ( $wp_filesystem->move( $source, $correct_dir ) ) {
            return trailingslashit( $correct_dir );
        }

        return new WP_Error( 'rename_failed', 'プラグインディレクトリ名の変更に失敗しました。' );
    }

    /**
     * README から説明を取得
     *
     * @return string 説明文
     */
    private function get_readme_description() {
        return 'Screw は WordPress サイトにオリジナル画像でのローディング画面を表示するプラグインです。';
    }

    /**
     * 変更履歴をフォーマット
     *
     * @param string $body リリースノート
     * @return string フォーマットされた変更履歴
     */
    private function format_changelog( $body ) {
        if ( empty( $body ) ) {
            return '<p>変更履歴はありません。</p>';
        }

        // Markdown を簡易的に HTML に変換
        $html = esc_html( $body );
        $html = nl2br( $html );

        // リスト項目を変換
        $html = preg_replace( '/^- (.+)$/m', '<li>$1</li>', $html );
        $html = preg_replace( '/(<li>.+<\/li>\s*)+/', '<ul>$0</ul>', $html );

        return $html;
    }

    /**
     * キャッシュをクリア
     *
     * @return bool 成功ならtrue、権限がなければfalse
     */
    public function clear_cache() {
        // 認可チェック: 管理者のみ実行可能
        if ( ! current_user_can( 'manage_options' ) ) {
            return false;
        }

        delete_transient( $this->cache_key );
        return true;
    }
}
